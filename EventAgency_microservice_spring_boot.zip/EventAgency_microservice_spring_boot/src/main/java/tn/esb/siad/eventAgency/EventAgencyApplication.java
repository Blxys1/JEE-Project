package tn.esb.siad.eventAgency;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventAgencyApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventAgencyApplication.class, args);
	}

}
