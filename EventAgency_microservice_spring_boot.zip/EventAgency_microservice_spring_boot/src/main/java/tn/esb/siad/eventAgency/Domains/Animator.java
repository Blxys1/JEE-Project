package tn.esb.siad.eventAgency.Domains;

public class Animator {
}
