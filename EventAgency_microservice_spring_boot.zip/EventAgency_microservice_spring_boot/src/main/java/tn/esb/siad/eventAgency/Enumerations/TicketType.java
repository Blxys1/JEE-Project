package tn.esb.siad.eventAgency.Enumerations;

public enum TicketType {
    VIP,
    NORMAL,
    STUDENT,
    FREE
}
