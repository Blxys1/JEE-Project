package tn.esb.siad.eventAgency.EventTest;

public interface Entity {
}
