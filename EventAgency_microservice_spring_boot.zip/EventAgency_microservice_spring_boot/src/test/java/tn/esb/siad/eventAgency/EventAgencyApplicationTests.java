package tn.esb.siad.eventAgency;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventAgencyApplicationTests {

	@Test
	void contextLoads() {
	}

}
